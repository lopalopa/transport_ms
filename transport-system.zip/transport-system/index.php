<?php
// Include the database connection
include('db.php');

// Fetch vehicle data from the database
$query = "SELECT * FROM vehicles";  // Assuming you have a 'vehicles' table
$result = mysqli_query($conn, $query);

$vehicles = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $vehicles[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Transport Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
    }

    .hero {
      background: linear-gradient(120deg, rgba(0, 123, 255, 0.8), rgba(0, 0, 0, 0.7)),
        url('https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&w=1600&q=80') no-repeat center center;
      background-size: cover;
      color: white;
      padding: 120px 20px;
      text-align: center;
    }

    .hero h1 {
      font-size: 3rem;
      font-weight: bold;
    }

    .features {
      background: linear-gradient(45deg, #f3f4f6, #e2e8f0);
      padding: 60px 20px;
    }

    .features i {
      font-size: 3rem;
      color: #0d6efd;
    }

    .about {
      background: #fff;
      padding: 60px 20px;
    }

    .cta {
      background: linear-gradient(to right, #4facfe, #00f2fe);
      color: white;
      padding: 60px 20px;
      text-align: center;
    }

    footer {
      background: #0a0a0a;
      color: #bbb;
      padding: 20px 0;
      text-align: center;
    }

    .btn-primary {
      background-color: #0d6efd;
      border-color: #0d6efd;
    }

    .vehicle-card {
      background: #f1f1f1;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      text-align: center;
      margin-bottom: 30px;
    }

    .vehicle-card img {
      width: 100%;
      height: auto;
      border-radius: 8px;
    }

    .vehicle-card h5 {
      margin-top: 20px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">TMS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="#">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="features.php">Features</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        <li class="nav-item"><a class="nav-link" href="register.php">SignUp</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero">
  <div class="container">
    <h1>Efficient Transport Management Starts Here</h1>
    <p class="lead">Track vehicles, assign drivers, manage routes – all in one system!</p>
    <a href="register.php" class="btn btn-primary btn-lg mt-3">Get Started</a>
  </div>
</section>

<!-- Features Section -->
<section id="features" class="features text-center">
  <div class="container">
    <h2 class="mb-5">Key Features</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <i class="bi bi-truck"></i>
        <h5 class="mt-3">Vehicle Management</h5>
        <p>Add, edit, and manage vehicle records efficiently.</p>
      </div>
      <div class="col-md-4">
        <i class="bi bi-person-vcard"></i>
        <h5 class="mt-3">Driver Profiles</h5>
        <p>Keep all driver data and assignments in one place.</p>
      </div>
      <div class="col-md-4">
        <i class="bi bi-map"></i>
        <h5 class="mt-3">Route & Schedule</h5>
        <p>Plan, view, and manage your transport routes & timings.</p>
      </div>
    </div>
  </div>
</section>

<!-- Vehicle Section (Dynamically fetched from DB) -->
<section id="vehicles" class="vehicles text-center">
  <div class="container">
    <h2 class="mb-5">Our Vehicles</h2>
    <div class="row">
      <?php foreach ($vehicles as $vehicle) : ?>
        <div class="col-md-4">
          <div class="vehicle-card">
            <?php
            // Check if image exists
            $image_path = 'uploads/' . $vehicle['image'];
            if (file_exists($image_path) && !empty($vehicle['image'])) {
                echo '<img src="' . $image_path . '" class="vehicle-img" alt="Vehicle Image">';
            } else {
                echo '<img src="uploads/no_image_available.jpg" class="vehicle-img" alt="No Image Available">';
            }
            ?>
            <h5 class="mt-3"><?php echo htmlspecialchars($vehicle['vehicle_name']); ?></h5>
            <p><strong>Type:</strong> <?php echo htmlspecialchars($vehicle['vehicle_type']); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($vehicle['status']); ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- About Section -->
<section id="about" class="about text-center">
  <div class="container">
    <h2 class="mb-4">About the Project</h2>
    <p class="lead">
      This project streamlines transportation operations by offering real-time management for vehicles, routes, drivers, and schedules – saving both time and resources.
    </p>
  </div>
</section>

<!-- CTA Section -->
<section id="contact" class="cta">
  <div class="container">
    <h2 class="mb-3">Login to Get Started</h2>
    <p class="lead">Powerful tools to manage your entire transportation system at your fingertips.</p>
    <a href="login.php" class="btn btn-light btn-lg">Login Now</a>
  </div>
</section>

<!-- Footer -->
<footer>
  <p>&copy; 2025 Transport Management System | Designed with ❤️</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
