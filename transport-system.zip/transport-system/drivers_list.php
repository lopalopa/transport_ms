<?php
session_start();
include('db.php');

// Check if user is logged in and is Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit();
}

// Fetch all drivers
$drivers = [];
$sql = "SELECT id, name, license_number, contact, status, created_at FROM drivers";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $drivers[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Drivers List - Transport Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Drivers List</h2>
    <a href="add_driver.php" class="btn btn-primary mb-3">Add New Driver</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>License Number</th>
                <th>Contact</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($drivers)) { ?>
                <tr>
                    <td colspan="6" class="text-center">No drivers found.</td>
                </tr>
            <?php } else { ?>
                <?php foreach ($drivers as $driver) { ?>
                    <tr>
                        <td><?php echo $driver['id']; ?></td>
                        <td><?php echo $driver['name']; ?></td>
                        <td><?php echo $driver['license_number']; ?></td>
                        <td><?php echo $driver['contact']; ?></td>
                        <td><?php echo $driver['status']; ?></td>
                        <td>
                            <a href="edit_driver.php?id=<?php echo $driver['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete_driver.php?id=<?php echo $driver['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this driver?')">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
