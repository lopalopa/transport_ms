<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include('db.php');

// Check if the user is an admin
if ($_SESSION['role'] != 'Admin') {
    $_SESSION['message'] = "You do not have permission to access this page.";
    header('Location: index.php');
    exit();
}

// Fetch all drivers from the database
$query = "SELECT * FROM drivers";
$result = $conn->query($query);

// Handle driver deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    // Delete driver from the database
    $delete_query = "DELETE FROM drivers WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Driver deleted successfully!";
    } else {
        $_SESSION['message'] = "Failed to delete driver.";
    }

    header('Location: manage_drivers.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Drivers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('header.php'); ?>

<div class="container mt-5">
    <h2>Manage Drivers</h2>
    
    <?php
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-info">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
    }
    ?>

    <a href="add_driver.php" class="btn btn-primary mb-3">Add New Driver</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Driver Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($driver = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $driver['id'] . "</td>";
                    echo "<td>" . htmlspecialchars($driver['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($driver['license_number']) . "</td>";
                    echo "<td>" . htmlspecialchars($driver['contact']) . "</td>";
                    echo "<td>
                            <a href='edit_driver.php?id=" . $driver['id'] . "' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='manage_drivers.php?delete_id=" . $driver['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this driver?\")'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' class='text-center'>No drivers found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include('footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
