<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit();
}

$route_name = $starting_point = $destination = $schedule = $vehicle_id = $driver_id = "";
$error = "";

// Fetch drivers
$drivers = [];
$driver_sql = "SELECT id, name FROM drivers WHERE status = 'Active'";
$driver_result = $conn->query($driver_sql);
if ($driver_result->num_rows > 0) {
    while ($row = $driver_result->fetch_assoc()) {
        $drivers[] = $row;
    }
}

// Fetch vehicles
$vehicles = [];
$vehicle_sql = "SELECT id, vehicle_no FROM vehicles WHERE status = 'Active'";
$vehicle_result = $conn->query($vehicle_sql);
if ($vehicle_result->num_rows > 0) {
    while ($row = $vehicle_result->fetch_assoc()) {
        $vehicles[] = $row;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $route_name = mysqli_real_escape_string($conn, $_POST['route_name']);
    $starting_point = mysqli_real_escape_string($conn, $_POST['starting_point']);
    $destination = mysqli_real_escape_string($conn, $_POST['destination']);
    $schedule = mysqli_real_escape_string($conn, $_POST['schedule']);
    $driver_id = mysqli_real_escape_string($conn, $_POST['driver_id']);
    $vehicle_id = mysqli_real_escape_string($conn, $_POST['vehicle_id']);

    if (empty($route_name) || empty($starting_point) || empty($destination) || empty($schedule) || empty($driver_id) || empty($vehicle_id)) {
        $error = "All fields are required.";
    } else {
        // Insert new route
        $sql = "INSERT INTO routes (route_name, starting_point, destination, schedule, vehicle_id, driver_id) 
                VALUES ('$route_name', '$starting_point', '$destination', '$schedule', '$vehicle_id', '$driver_id')";
        
        if ($conn->query($sql) === TRUE) {
            // Update driver status to 'Reserved'
            $update_driver_sql = "UPDATE drivers SET status = 'Reserved' WHERE id = '$driver_id'";
            $conn->query($update_driver_sql);
            
            // Update vehicle status to 'Reserved'
            $update_vehicle_sql = "UPDATE vehicles SET status = 'Reserved' WHERE id = '$vehicle_id'";
            $conn->query($update_vehicle_sql);
            
            // Redirect to routes list
            header('Location: routes_list.php');
            exit();
        } else {
            $error = "Failed to add the route: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!-- HTML FORM -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Add Route</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">Add Route</h2>
    <?php if (!empty($error)) { echo '<div class="alert alert-danger">' . $error . '</div>'; } ?>
    <form method="POST" action="add_route.php">
        <div class="mb-3">
            <label for="route_name" class="form-label">Route Name/Number</label>
            <input type="text" class="form-control" name="route_name" id="route_name" required />
        </div>
        <div class="mb-3">
            <label for="starting_point" class="form-label">Starting Point</label>
            <input type="text" class="form-control" name="starting_point" id="starting_point" required />
        </div>
        <div class="mb-3">
            <label for="destination" class="form-label">Destination</label>
            <input type="text" class="form-control" name="destination" id="destination" required />
        </div>
        <div class="mb-3">
            <label for="schedule" class="form-label">Schedule</label>
            <input type="text" class="form-control" name="schedule" id="schedule" placeholder="e.g., Mon-Fri 9AM-5PM" required />
        </div>
        <div class="mb-3">
            <label for="driver_id" class="form-label">Assign Driver</label>
            <select class="form-select" name="driver_id" id="driver_id" required>
                <option value="">Select Driver</option>
                <?php foreach ($drivers as $driver): ?>
                    <option value="<?= $driver['id'] ?>"><?= $driver['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="vehicle_id" class="form-label">Assign Vehicle</label>
            <select class="form-select" name="vehicle_id" id="vehicle_id" required>
                <option value="">Select Vehicle</option>
                <?php foreach ($vehicles as $vehicle): ?>
                    <option value="<?= $vehicle['id'] ?>"><?= $vehicle['vehicle_no'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Add Route</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
