<?php
session_start();
include('db.php');

// Check if the user is logged in and is an admin or authorized role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit();
}

// Check if the ID is set
if (isset($_GET['id'])) {
    $route_id = intval($_GET['id']);

    // Prepare and execute delete query
    $sql = "DELETE FROM routes WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $route_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Route deleted successfully.";
    } else {
        $_SESSION['message'] = "Failed to delete route: " . $conn->error;
    }

    $stmt->close();
    $conn->close();

    // Redirect to routes list or previous page
    header("Location: routes_list.php");
    exit();
} else {
    echo "Invalid route ID.";
}
?>
