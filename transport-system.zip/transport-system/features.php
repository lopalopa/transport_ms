<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Features - Transport Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f8f9fa;
            padding-top: 60px;
        }
        .features-section {
            max-width: 1000px;
            margin: 0 auto;
            background: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .feature-item {
            margin-bottom: 30px;
        }
        .feature-item h5 {
            color: #0d6efd;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="features-section">
        <h2 class="text-center mb-4">System Features</h2>

        <div class="feature-item">
            <h5>🚗 Vehicle Management</h5>
            <p>Add, view, and delete vehicle information including vehicle name, number, type, status, and images.</p>
        </div>

        <div class="feature-item">
            <h5>🧑‍💼 User Roles & Authentication</h5>
            <p>Supports different roles like Admin and User with secure login and session handling.</p>
        </div>

        <div class="feature-item">
            <h5>📅 Route & Schedule Management</h5>
            <p>Manage transport routes and scheduling for efficient planning (if included in your project).</p>
        </div>

        <div class="feature-item">
            <h5>📊 Reports & Status</h5>
            <p>Generate attendance or availability reports and view vehicle statuses in real-time.</p>
        </div>

        <div class="feature-item">
            <h5>🖼 Image Upload</h5>
            <p>Upload and display vehicle images for better identification and records.</p>
        </div>

        <div class="feature-item">
            <h5>⚙️ Admin Panel</h5>
            <p>Dedicated panel for managing vehicles, users, and routes (based on implementation).</p>
        </div>

        <a href="index.php" class="btn btn-primary mt-4">Back to Dashboard</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
