<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include('db.php');

// Check if the user is an admin
if ($_SESSION['role'] != 'Admin') {
    $_SESSION['message'] = "You do not have permission to access this page.";
    header('Location: index.php');
    exit();
}

// Delete route logic
if (isset($_GET['delete_id'])) {
    $route_id = $_GET['delete_id'];

    // Query to delete the route
    $delete_query = "DELETE FROM routes WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param('i', $route_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Route deleted successfully!";
    } else {
        $_SESSION['message'] = "Error deleting route.";
    }
    header('Location: manage_routes.php');
    exit();
}

// Fetch all routes
$route_query = "SELECT * FROM routes";
$route_result = $conn->query($route_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Routes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('header.php'); ?>

<div class="container mt-5">
    <h2>Manage Routes</h2>

    <?php
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-info">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
    }
    ?>

    <a href="add_route.php" class="btn btn-primary mb-3">Add New Route</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Route Name</th>
                <th>Starting Point</th>
                <th>Ending Point</th>
                <th>Distance (km)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($route_result->num_rows > 0) {
                while ($route = $route_result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $route['id'] . "</td>
                            <td>" . $route['route_name'] . "</td>
                            <td>" . $route['starting_point'] . "</td>
                            <td>" . $route['destination'] . "</td>
                            <td>" . $route['schedule'] . "</td>
                            <td>
                                <a href='edit_route.php?id=" . $route['id'] . "' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='manage_routes.php?delete_id=" . $route['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this route?\")'>Delete</a>
                            </td>
                        </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No routes found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include('footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
