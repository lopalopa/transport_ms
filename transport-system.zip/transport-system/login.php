<?php
session_start();
include('db.php'); // Include your database connection file

// Redirect to dashboard if already logged in
if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['role'];
    if ($role === 'Admin') {
        header('Location: admin_dashboard.php'); // Redirect to admin dashboard
        exit();
    } else {
        header('Location: user_dashboard.php'); // Redirect to user dashboard
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate the form inputs
    if (empty($email) || empty($password)) {
        $error = "Email and password are required!";
    } else {
        // Prepare SQL query to check if the user exists
        $sql = "SELECT id, name, email, password, role FROM users WHERE email = ? LIMIT 1";
        if ($stmt = $conn->prepare($sql)) {
            // Bind the parameters
            $stmt->bind_param("s", $email);
            
            // Execute the query
            $stmt->execute();
            
            // Get the result
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                // Fetch the user data
                $user = $result->fetch_assoc();
                
                // Verify the password
                if (password_verify($password, $user['password'])) {
                    // Set session variables
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['name'] = $user['name'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];

                    // Redirect based on role
                    if ($user['role'] === 'Admin') {
                        header('Location: admin_dashboard.php'); // Admin dashboard
                    } else {
                        header('Location: user_dashboard.php'); // User dashboard
                    }
                    exit();
                } else {
                    $error = "Invalid password!";
                }
            } else {
                $error = "No account found with this email!";
            }

            // Close the prepared statement
            $stmt->close();
        } else {
            $error = "Error: Could not prepare the SQL statement.";
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login - Transport Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f7f7f7;
            padding-top: 50px;
        }
        .login-form {
            max-width: 500px;
            margin: 0 auto;
            padding: 30px;
            background-color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="login-form">
    <h2 class="text-center mb-4">Login</h2>
    <?php if (isset($error)) { echo '<div class="alert alert-danger">' . $error . '</div>'; } ?>
    <form action="login.php" method="POST">
        <div class="mb-3">
            <label for="email" class="form-label">Email address</label>
            <input type="email" class="form-control" id="email" name="email" required />
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required />
        </div>
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
    <p class="text-center mt-3">
        Don't have an account? <a href="register.php">Register here</a>
    </p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
