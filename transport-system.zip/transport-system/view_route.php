<?php
session_start();
include('db.php');

// Redirect if not logged in as Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'User') {
    header('Location: login.php');
    exit();
}

if (!isset($_GET['id'])) {
    echo "No route ID specified.";
    exit();
}

$route_id = intval($_GET['id']);
$sql = "SELECT r.*, 
               d.name AS driver_name, 
               v.vehicle_no 
        FROM routes r
        LEFT JOIN drivers d ON r.driver_id = d.id
        LEFT JOIN vehicles v ON r.vehicle_id = v.id
        WHERE r.id = $route_id";

$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "Route not found.";
    exit();
}

$route = $result->fetch_assoc();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Route</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Route Details</h2>
    <table class="table table-bordered">
        <tr><th>Route Name/Number</th><td><?= htmlspecialchars($route['route_name']) ?></td></tr>
        <tr><th>Starting Point</th><td><?= htmlspecialchars($route['starting_point']) ?></td></tr>
        <tr><th>Destination</th><td><?= htmlspecialchars($route['destination']) ?></td></tr>
        <tr><th>Schedule</th><td><?= htmlspecialchars($route['schedule']) ?></td></tr>
        <tr><th>Vehicle</th><td><?= htmlspecialchars($route['vehicle_no']) ?></td></tr>
        <tr><th>Driver</th><td><?= htmlspecialchars($route['driver_name']) ?></td></tr>
    </table>
    <a href="routes_list.php" class="btn btn-secondary">Back to Routes</a>
</div>
</body>
</html>
