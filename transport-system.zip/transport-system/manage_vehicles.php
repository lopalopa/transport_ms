<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include('db.php');

// Check if the user is an admin
if ($_SESSION['role'] != 'Admin') {
    $_SESSION['message'] = "You do not have permission to access this page.";
    header('Location: index.php');
    exit();
}

// Fetch all vehicles from the database
$query = "SELECT * FROM vehicles";
$result = $conn->query($query);

// Handle vehicle deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    // Delete vehicle from the database
    $delete_query = "DELETE FROM vehicles WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Vehicle deleted successfully!";
    } else {
        $_SESSION['message'] = "Failed to delete vehicle.";
    }

    header('Location: manage_vehicles.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Vehicles</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('header.php'); ?>

<div class="container mt-5">
    <h2>Manage Vehicles</h2>
    
    <?php
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-info">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
    }
    ?>

    <a href="add_vehicle.php" class="btn btn-primary mb-3">Add New Vehicle</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Vehicle No</th>
                <th>Vehicle Name</th>
                <th>Driver Id </th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($vehicle = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $vehicle['id'] . "</td>";
                    echo "<td>" . htmlspecialchars($vehicle['vehicle_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($vehicle['vehicle_no']) . "</td>";
                    echo "<td>" . htmlspecialchars($vehicle['driver_id']) . "</td>";
                    echo "<td>
                            <a href='edit_vehicle.php?id=" . $vehicle['id'] . "' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='manage_vehicles.php?delete_id=" . $vehicle['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this vehicle?\")'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' class='text-center'>No vehicles found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include('footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
