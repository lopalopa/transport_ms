<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include('db.php');

// Check if the user is an admin
if ($_SESSION['role'] != 'Admin') {
    $_SESSION['message'] = "You do not have permission to access this page.";
    header('Location: index.php');
    exit();
}

// Check if the driver ID is provided in the URL
if (isset($_GET['id'])) {
    $driver_id = $_GET['id'];

    // Fetch the driver details from the database
    $query = "SELECT * FROM drivers WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $driver = $result->fetch_assoc();

    // If the driver does not exist, redirect to manage_drivers.php
    if (!$driver) {
        $_SESSION['message'] = "Driver not found.";
        header('Location: manage_drivers.php');
        exit();
    }
} else {
    $_SESSION['message'] = "Invalid request.";
    header('Location: manage_drivers.php');
    exit();
}

// Handle form submission for editing driver details
if (isset($_POST['update'])) {
    $driver_name = $_POST['name'];
    $license_number = $_POST['license_number'];
    $contact_number = $_POST['contact'];

    // Update the driver's details in the database
    $update_query = "UPDATE drivers SET name = ?, license_number = ?, contact = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sssi", $driver_name, $license_number, $contact_number, $driver_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Driver details updated successfully!";
        header('Location: manage_drivers.php');
        exit();
    } else {
        $_SESSION['message'] = "Failed to update driver details.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Driver</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('header.php'); ?>

<div class="container mt-5">
    <h2>Edit Driver Details</h2>

    <?php
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-info">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
    }
    ?>

    <form method="POST" action="edit_driver.php?id=<?php echo $driver['id']; ?>">
        <div class="mb-3">
            <label for="driver_name" class="form-label">Driver Name</label>
            <input type="text" class="form-control" id="driver_name" name="name" value="<?php echo htmlspecialchars($driver['name']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="license_number" class="form-label">License Number</label>
            <input type="text" class="form-control" id="license_number" name="license_number" value="<?php echo htmlspecialchars($driver['license_number']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="contact_number" class="form-label">Contact Number</label>
            <input type="text" class="form-control" id="contact_number" name="contact" value="<?php echo htmlspecialchars($driver['contact']); ?>" required>
        </div>

        <button type="submit" name="update" class="btn btn-primary">Update Driver</button>
    </form>
</div>

<?php include('footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
