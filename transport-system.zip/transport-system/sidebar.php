<?php
// Start the session to access session variables
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<div class="d-flex flex-column flex-shrink-0 bg-light" style="width: 250px;">
  <div class="p-3">
    <h4>Dashboard</h4>
  </div>
  <hr>

  <!-- Sidebar Navigation -->
  <ul class="nav nav-pills flex-column mb-auto">
    <?php if (isset($_SESSION['user_id'])) : ?>
      <!-- If user is logged in, display role-based content -->
      
      <?php if ($_SESSION['role'] === 'Admin') : ?>
        <!-- Admin-specific links -->
        <li class="nav-item">
          <a href="admin_dashboard.php" class="nav-link active" aria-current="page">
            <i class="bi bi-house-door"></i> Admin Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a href="manage_users.php" class="nav-link">
            <i class="bi bi-person-badge"></i> Manage Users
          </a>
        </li>
        <li class="nav-item">
          <a href="manage_vehicles.php" class="nav-link">
            <i class="bi bi-car-front"></i> Manage Vehicles
          </a>
        </li>
        <li class="nav-item">
          <a href="manage_drivers.php" class="nav-link">
            <i class="bi bi-car-front"></i> Manage Drivers
          </a>
        </li>
        <li class="nav-item">
          <a href="manage_routes.php" class="nav-link">
            <i class="bi bi-car-front"></i> Manage Roots
          </a>
        </li>
        <li class="nav-item">
          <a href="view_reports.php" class="nav-link">
            <i class="bi bi-bar-chart-line"></i> View Reports
          </a>
        </li>

      <?php elseif ($_SESSION['role'] === 'User') : ?>
        <!-- User-specific links -->
        <li class="nav-item">
          <a href="user_dashboard.php" class="nav-link active" aria-current="page">
            <i class="bi bi-house-door"></i> User Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a href="vehicle_list.php" class="nav-link">
            <i class="bi bi-car-front"></i> View Vehicles
          </a>
        </li>
        <li class="nav-item">
          <a href="booking_history.php" class="nav-link">
            <i class="bi bi-file-earmark"></i> Booking History
          </a>
        </li>
        <li class="nav-item">
          <a href="logout.php" class="nav-link text-danger">
            <i class="bi bi-box-arrow-right"></i> Logout
          </a>
        </li>
      <?php endif; ?>

    <?php else : ?>
      <!-- If user is not logged in, show login/signup options -->
      <li class="nav-item">
        <a href="login.php" class="nav-link">
          <i class="bi bi-box-arrow-in-right"></i> Login
        </a>
      </li>
      <li class="nav-item">
        <a href="register.php" class="nav-link">
          <i class="bi bi-person-plus"></i> Sign Up
        </a>
      </li>
    <?php endif; ?>
  </ul>
  
</div>

<!-- Optional Bootstrap JavaScript (if using for toggling) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
