<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit();
}

$route_id = $route_name = $starting_point = $destination = $schedule = $vehicle_id = $driver_id = "";
$error = "";

// Fetch the route details based on the ID
if (isset($_GET['id'])) {
    $route_id = $_GET['id'];
    $route_sql = "SELECT * FROM routes WHERE id = '$route_id'";
    $route_result = $conn->query($route_sql);
    if ($route_result->num_rows > 0) {
        $route = $route_result->fetch_assoc();
        $route_name = $route['route_name'];
        $starting_point = $route['starting_point'];
        $destination = $route['destination'];
        $schedule = $route['schedule'];
        $vehicle_id = $route['vehicle_id'];
        $driver_id = $route['driver_id'];
    } else {
        $error = "Route not found.";
    }
} else {
    $error = "Invalid route ID.";
}

// Fetch drivers
$drivers = [];
$driver_sql = "SELECT id, name FROM drivers WHERE status = 'Active'";
$driver_result = $conn->query($driver_sql);
if ($driver_result->num_rows > 0) {
    while ($row = $driver_result->fetch_assoc()) {
        $drivers[] = $row;
    }
}

// Fetch vehicles
$vehicles = [];
$vehicle_sql = "SELECT id, vehicle_no FROM vehicles WHERE status = 'Active'";
$vehicle_result = $conn->query($vehicle_sql);
if ($vehicle_result->num_rows > 0) {
    while ($row = $vehicle_result->fetch_assoc()) {
        $vehicles[] = $row;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $route_name = mysqli_real_escape_string($conn, $_POST['route_name']);
    $starting_point = mysqli_real_escape_string($conn, $_POST['starting_point']);
    $destination = mysqli_real_escape_string($conn, $_POST['destination']);
    $schedule = mysqli_real_escape_string($conn, $_POST['schedule']);
    $driver_id = mysqli_real_escape_string($conn, $_POST['driver_id']);
    $vehicle_id = mysqli_real_escape_string($conn, $_POST['vehicle_id']);

    if (empty($route_name) || empty($starting_point) || empty($destination) || empty($schedule) || empty($driver_id) || empty($vehicle_id)) {
        $error = "All fields are required.";
    } else {
        // Update the route in the database
        $update_sql = "UPDATE routes SET route_name = '$route_name', starting_point = '$starting_point', 
                       destination = '$destination', schedule = '$schedule', vehicle_id = '$vehicle_id', driver_id = '$driver_id' 
                       WHERE id = '$route_id'";

        if ($conn->query($update_sql) === TRUE) {
            // Update driver status to 'Reserved'
            $update_driver_sql = "UPDATE drivers SET status = 'Reserved' WHERE id = '$driver_id'";
            $conn->query($update_driver_sql);
            
            // Update vehicle status to 'Reserved'
            $update_vehicle_sql = "UPDATE vehicles SET status = 'Reserved' WHERE id = '$vehicle_id'";
            $conn->query($update_vehicle_sql);
            
            // Redirect to routes list
            header('Location: routes_list.php');
            exit();
        } else {
            $error = "Failed to update the route: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!-- HTML FORM -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Route</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">Edit Route</h2>
    <?php if (!empty($error)) { echo '<div class="alert alert-danger">' . $error . '</div>'; } ?>
    <form method="POST" action="edit_route.php?route_id=<?= $route_id ?>">
        <div class="mb-3">
            <label for="route_name" class="form-label">Route Name/Number</label>
            <input type="text" class="form-control" name="route_name" id="route_name" value="<?= $route_name ?>" required />
        </div>
        <div class="mb-3">
            <label for="starting_point" class="form-label">Starting Point</label>
            <input type="text" class="form-control" name="starting_point" id="starting_point" value="<?= $starting_point ?>" required />
        </div>
        <div class="mb-3">
            <label for="destination" class="form-label">Destination</label>
            <input type="text" class="form-control" name="destination" id="destination" value="<?= $destination ?>" required />
        </div>
        <div class="mb-3">
            <label for="schedule" class="form-label">Schedule</label>
            <input type="text" class="form-control" name="schedule" id="schedule" value="<?= $schedule ?>" placeholder="e.g., Mon-Fri 9AM-5PM" required />
        </div>
        <div class="mb-3">
            <label for="driver_id" class="form-label">Assign Driver</label>
            <select class="form-select" name="driver_id" id="driver_id" required>
                <option value="">Select Driver</option>
                <?php foreach ($drivers as $driver): ?>
                    <option value="<?= $driver['id'] ?>" <?= $driver['id'] == $driver_id ? 'selected' : '' ?>><?= $driver['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="vehicle_id" class="form-label">Assign Vehicle</label>
            <select class="form-select" name="vehicle_id" id="vehicle_id" required>
                <option value="">Select Vehicle</option>
                <?php foreach ($vehicles as $vehicle): ?>
                    <option value="<?= $vehicle['id'] ?>" <?= $vehicle['id'] == $vehicle_id ? 'selected' : '' ?>><?= $vehicle['vehicle_no'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update Route</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
