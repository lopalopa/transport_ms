<?php
session_start();
include('db.php');

// Check if user is logged in and is Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit();
}

$vehicle_no = $vehicle_name = $vehicle_type = $driver_id = $image = "";
$error = "";

// Get list of active drivers for dropdown
$drivers = [];
$driver_sql = "SELECT id, name FROM drivers WHERE status = 'Active'";
$result = $conn->query($driver_sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $drivers[] = $row;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $vehicle_no = mysqli_real_escape_string($conn, $_POST['vehicle_no']);
    $vehicle_name = mysqli_real_escape_string($conn, $_POST['vehicle_name']);
    $vehicle_type = mysqli_real_escape_string($conn, $_POST['vehicle_type']);
    $driver_id = mysqli_real_escape_string($conn, $_POST['driver_id']);

    // Handling image upload
    $image_name = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_name = time() . "_" . $_FILES['image']['name']; // Unique image name
        $image_path = "uploads/" . $image_name;

        // Move the uploaded file to the "uploads" directory
        if (!move_uploaded_file($image_tmp, $image_path)) {
            $error = "Failed to upload image.";
        }
    }

    if (empty($vehicle_no) || empty($vehicle_name) || empty($vehicle_type) || empty($driver_id)) {
        $error = "All fields are required.";
    } else {
        // Insert vehicle data into database
        $sql = "INSERT INTO vehicles (vehicle_no, vehicle_name, vehicle_type, driver_id, image)
                VALUES ('$vehicle_no', '$vehicle_name', '$vehicle_type', '$driver_id', '$image_name')";

        if ($conn->query($sql) === TRUE) {
            header('Location: vehicles_list.php');
            exit();
        } else {
            $error = "Failed to add vehicle: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!-- HTML Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Add Vehicle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Add Vehicle</h2>
    <?php if (!empty($error)) { echo '<div class="alert alert-danger">' . $error . '</div>'; } ?>
    <form method="POST" action="add_vehicle.php" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="vehicle_no" class="form-label">Vehicle Number</label>
            <input type="text" class="form-control" id="vehicle_no" name="vehicle_no" required />
        </div>
        <div class="mb-3">
            <label for="vehicle_name" class="form-label">Vehicle Name</label>
            <input type="text" class="form-control" id="vehicle_name" name="vehicle_name" required />
        </div>
        <div class="mb-3">
            <label for="vehicle_type" class="form-label">Vehicle Type</label>
            <input type="text" class="form-control" id="vehicle_type" name="vehicle_type" required />
        </div>
        <div class="mb-3">
            <label for="driver_id" class="form-label">Assign Driver</label>
            <select class="form-select" id="driver_id" name="driver_id" required>
                <option value="">Select Driver</option>
                <?php foreach ($drivers as $driver): ?>
                    <option value="<?= $driver['id'] ?>"><?= $driver['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">Vehicle Image</label>
            <input type="file" class="form-control" id="image" name="image" />
        </div>
        <button type="submit" class="btn btn-primary">Add Vehicle</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
