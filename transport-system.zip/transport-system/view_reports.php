<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include('db.php');

// Check if the user is an admin
if ($_SESSION['role'] != 'Admin') {
    $_SESSION['message'] = "You do not have permission to access this page.";
    header('Location: index.php');
    exit();
}

// Fetch vehicles report
$vehicle_query = "SELECT * FROM vehicles";
$vehicle_result = $conn->query($vehicle_query);

// Fetch drivers report
$driver_query = "SELECT * FROM drivers";
$driver_result = $conn->query($driver_query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('header.php'); ?>

<div class="container mt-5">
    <h2>Reports Dashboard</h2>

    <?php
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-info">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
    }
    ?>

    <div class="row">
        <!-- Vehicles Report -->
        <div class="col-md-6">
            <h3>Vehicles Report</h3>
            <?php if ($vehicle_result->num_rows > 0): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Vehicle ID</th>
                            <th>Vehicle Name</th>
                            <th>Driver</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($vehicle = $vehicle_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $vehicle['id']; ?></td>
                                <td><?php echo $vehicle['vehicle_no']; ?></td>
                                <td><?php echo $vehicle['vehicle_name']; ?></td>
                                <td><?php echo $vehicle['driver_id']; ?></td>
                                <td><?php echo $vehicle['status']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No vehicle data available.</p>
            <?php endif; ?>
        </div>

        <!-- Drivers Report -->
        <div class="col-md-6">
            <h3>Drivers Report</h3>
            <?php if ($driver_result->num_rows > 0): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Driver Name</th>
                            <th>License Number</th>
                            <th>Contact</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($driver = $driver_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $driver['id']; ?></td>
                                <td><?php echo $driver['name']; ?></td>
                                <td><?php echo $driver['license_number']; ?></td>
                                <td><?php echo $driver['contact']; ?></td>
                                <td><?php echo $driver['status']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No driver data available.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
