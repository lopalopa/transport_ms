<?php
include('db.php');

if (!isset($_GET['id'])) {
    echo "Vehicle ID is missing.";
    exit;
}

$id = intval($_GET['id']);
$sql = "SELECT * FROM vehicles WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows !== 1) {
    echo "Vehicle not found.";
    exit;
}

$vehicle = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vehicle_no = $_POST['vehicle_no'];
    $vehicle_name = $_POST['vehicle_name'];
    $vehicle_type = $_POST['vehicle_type'];
    $status = $_POST['status'];

    // Image upload handling
    $image = $vehicle['image']; // default existing image
    if (!empty($_FILES['image']['name'])) {
        $image = basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], "uploads/" . $image);
    }

    $update_sql = "UPDATE vehicles SET 
        vehicle_no = '$vehicle_no',
        vehicle_name = '$vehicle_name',
        vehicle_type = '$vehicle_type',
        status = '$status',
        image = '$image'
        WHERE id = $id";

    if ($conn->query($update_sql)) {
        header("Location: view_vehicle.php?id=$id");
        exit;
    } else {
        echo "Error updating vehicle: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Vehicle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container mt-5">
    <h2>Edit Vehicle</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Vehicle Number</label>
            <input type="text" name="vehicle_no" class="form-control" value="<?= htmlspecialchars($vehicle['vehicle_no']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Vehicle Name</label>
            <input type="text" name="vehicle_name" class="form-control" value="<?= htmlspecialchars($vehicle['vehicle_name']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Vehicle Type</label>
            <input type="text" name="vehicle_type" class="form-control" value="<?= htmlspecialchars($vehicle['vehicle_type']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-control">
                <option value="Active" <?= $vehicle['status'] === 'Active' ? 'selected' : '' ?>>Active</option>
                <option value="Inactive" <?= $vehicle['status'] === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Vehicle Image</label><br>
            <?php if ($vehicle['image']): ?>
                <img src="uploads/<?= htmlspecialchars($vehicle['image']) ?>" width="100" height="80" class="mb-2"><br>
            <?php endif; ?>
            <input type="file" name="image" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Update Vehicle</button>
        <a href="vehicles_list.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
