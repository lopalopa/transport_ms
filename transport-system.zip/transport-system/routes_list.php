<?php
session_start();
include('db.php'); // Include database connection file

// Check if user is logged in and is Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit();
}

// Fetch routes along with vehicle and driver details
$sql = "SELECT r.id, r.route_name, r.starting_point, r.destination, r.schedule, v.vehicle_name, d.name AS driver_name 
        FROM routes r
        JOIN vehicles v ON r.vehicle_id = v.id
        JOIN drivers d ON r.driver_id = d.id";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Routes List - Transport Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Routes List</h2>
        
        <!-- Table to display routes -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Route Name</th>
                    <th>Starting Point</th>
                    <th>Destination</th>
                    <th>Schedule</th>
                    <th>Vehicle Name</th>
                    <th>Driver Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Loop through each route and display details
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['route_name']}</td>
                                <td>{$row['starting_point']}</td>
                                <td>{$row['destination']}</td>
                                <td>{$row['schedule']}</td>
                                <td>{$row['vehicle_name']}</td>
                                <td>{$row['driver_name']}</td>
                                <td>
                                    <a href='edit_route.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                    <a href='delete_route.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this route?\")'>Delete</a>
                                </td>
                            </tr>";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No routes found</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <a href="add_route.php" class="btn btn-primary">Add New Route</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
