<?php
session_start();
require 'db.php'; // Ensure this file contains your DB connection setup

// Optional: Access Control
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch vehicles from DB
$sql = "SELECT * FROM vehicles";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Vehicles List - Transport Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">TMS</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <?php if ($_SESSION['role'] === 'admin') : ?>
          <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="user_dashboard.php">Dashboard</a></li>
        <?php endif; ?>
        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Content -->
<div class="container mt-5">
  <h2 class="mb-4">List of Vehicles</h2>

  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Vehicle Name</th>
        <th>Type</th>
        <th>Status</th>
        <th>Image</th>
      </tr>
    </thead>
    <tbody>
      <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?= $row['id']; ?></td>
            <td><?= htmlspecialchars($row['vehicle_name']); ?></td>
            <td><?= htmlspecialchars($row['vehicle_type']); ?></td>
            <td><?= htmlspecialchars($row['status']); ?></td>
            <td>
              <?php if ($row['image']): ?>
                <img src="uploads/<?= htmlspecialchars($row['image']); ?>" alt="Vehicle Image" width="80" height="50">
              <?php else: ?>
                No Image
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr>
          <td colspan="5" class="text-center">No vehicles found</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Footer -->
<footer class="text-center py-3 bg-dark text-light mt-5">
  <p>&copy; <?= date('Y'); ?> Transport Management System</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
