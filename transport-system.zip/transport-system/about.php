<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About - Transport Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f8f9fa;
            padding-top: 60px;
        }
        .about-section {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .about-section h2 {
            text-align: center;
            color: #0d6efd;
            margin-bottom: 20px;
        }
        .about-section p {
            font-size: 1.1rem;
            line-height: 1.8;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="about-section">
        <h2>About This System</h2>
        <p>
            The <strong>Transport Management System</strong> is a web-based application designed to manage vehicles, routes, users, and transportation-related tasks efficiently. The primary goal of this system is to simplify and digitize the traditional methods of managing transport operations.
        </p>
        <p>
            Users can easily view vehicle details, check availability, and manage records through an intuitive interface. Admins can add or delete vehicles, assign routes, and generate useful reports for decision-making. This system is ideal for schools, logistics companies, and institutions requiring organized transport data.
        </p>
        <p>
            Developed using <strong>PHP</strong>, <strong>MySQL</strong>, and <strong>Bootstrap</strong>, this project offers a reliable and user-friendly interface for smooth transport management.
        </p>
        <p>
            <strong>Developer:</strong> @lopalopa2007<br>
            <strong>Project Type:</strong> Academic / Practical Project
        </p>

        <a href="index.php" class="btn btn-primary mt-4">Back to Dashboard</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
