<?php
session_start();
include('db.php'); // Include your database connection file

// Redirect to login page if user is not logged in or is not a regular user
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'User') {
    header('Location: login.php');
    exit();
}

// Fetch vehicles from the database
$sql = "SELECT * FROM vehicles";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>View Vehicles - Transport Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f7f7f7;
            padding-top: 50px;
        }
        .table-container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 30px;
            background-color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .vehicle-img {
            width: 100px;
            height: 100px;
            object-fit: cover;
        }
    </style>
</head>
<body>

<div class="table-container">
    <h2 class="text-center mb-4">Vehicles List</h2>

    <?php if ($result->num_rows > 0) { ?>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Vehicle Name</th>
                    <th>Vehicle Type</th>
                    <th>Status</th>
                    <th>Vehicle Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count = 1;
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $count . '</td>';
                    echo '<td>' . htmlspecialchars($row['vehicle_name']) . '</td>';
                    echo '<td>' . htmlspecialchars($row['vehicle_type']) . '</td>';
                    echo '<td>' . htmlspecialchars($row['status']) . '</td>';

                    echo '<td>';
                    if (!empty($row['image'])) {
                        echo '<img src="uploads/' . htmlspecialchars($row['image']) . '" class="vehicle-img" alt="Vehicle Image">';
                    } else {
                        echo 'No Image';
                    }
                    echo '</td>';

                    echo '<td><a href="view_vehicle.php?id=' . $row['id'] . '" class="btn btn-info btn-sm">View</a></td>';
                    echo '</tr>';
                    $count++;
                }
                ?>
            </tbody>
        </table>
    <?php } else { ?>
        <p class="text-center">No vehicles found.</p>
    <?php } ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
