<?php
session_start();

// Check if the user is logged in, else redirect to login page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Include the database connection
include('db.php');

// Get user information (Assuming a session variable for the logged-in user)
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Fetch vehicles and routes for the user
$vehicles_query = "SELECT * FROM vehicles";
$routes_query = "SELECT * FROM routes";

$vehicles_result = mysqli_query($conn, $vehicles_query);
$routes_result = mysqli_query($conn, $routes_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="user_dashboard.php">Transport Management System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="user_dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_vehicle_user.php">Vehicles</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_routes_user.php">Routes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero">
        <h1>Welcome to Your Dashboard, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h1>
        <p>Manage your vehicles, routes, and more.</p>
    </div>

    <!-- Dashboard Overview -->
    <div class="container">
        <div class="row">
            <!-- Vehicles -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3>Vehicles</h3>
                    </div>
                    <div class="card-body">
                        <p>You have <?php echo mysqli_num_rows($vehicles_result); ?> vehicles in the system.</p>
                        <a href="view_vehicle_user.php" class="btn btn-primary">View All Vehicles</a>
                    </div>
                </div>
            </div>

            <!-- Routes -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3>Routes</h3>
                    </div>
                    <div class="card-body">
                        <p>You have <?php echo mysqli_num_rows($routes_result); ?> routes in the system.</p>
                        <a href="view_routes_user.php" class="btn btn-primary">View All Routes</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Transport Management System | All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
