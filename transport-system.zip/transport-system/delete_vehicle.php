<?php
session_start();
include('db.php');

// Only allow logged-in users with appropriate role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit();
}

// Check if vehicle ID is passed
if (isset($_GET['id'])) {
    $vehicle_id = intval($_GET['id']);

    // Optionally fetch the image path to delete the file as well
    $img_sql = "SELECT image FROM vehicles WHERE id = ?";
    $img_stmt = $conn->prepare($img_sql);
    $img_stmt->bind_param("i", $vehicle_id);
    $img_stmt->execute();
    $img_result = $img_stmt->get_result();
    $img_row = $img_result->fetch_assoc();

    if ($img_row && !empty($img_row['image'])) {
        $image_path = 'uploads/' . $img_row['image'];
        if (file_exists($image_path)) {
            unlink($image_path); // Delete the image file
        }
    }
    $img_stmt->close();

    // Delete the vehicle record
    $sql = "DELETE FROM vehicles WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $vehicle_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Vehicle deleted successfully.";
    } else {
        $_SESSION['message'] = "Failed to delete vehicle: " . $conn->error;
    }

    $stmt->close();
    $conn->close();

    // Redirect to vehicle list
    header("Location: vehicles_list.php");
    exit();
} else {
    echo "Invalid vehicle ID.";
}
?>
