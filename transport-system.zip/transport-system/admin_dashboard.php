<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Dashboard - Transport Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <!-- Navbar -->
<?php include 'header.php';?>
  <!-- Main Dashboard -->
  <div class="container mt-5">
    <div class="row">
        <div class="col-md-3">
        <?php include 'sidebar.php';?>

        </div>
<div class="col-md-9">    <h1 class="mb-4">Welcome, Admin!</h1>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="card text-white bg-primary h-100">
          <div class="card-body text-center">
            <h5 class="card-title">Add Vehicle</h5>
            <a href="add_vehicle.php" class="btn btn-light mt-2">Go</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card text-white bg-success h-100">
          <div class="card-body text-center">
            <h5 class="card-title">Add Driver</h5>
            <a href="add_driver.php" class="btn btn-light mt-2">Go</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card text-white bg-warning h-100">
          <div class="card-body text-center">
            <h5 class="card-title">Add Route</h5>
            <a href="add_route.php" class="btn btn-light mt-2">Go</a>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card text-white bg-info h-100">
          <div class="card-body text-center">
            <h5 class="card-title">View Vehicles</h5>
            <a href="view_vehicles.php" class="btn btn-light mt-2">Go</a>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card text-white bg-secondary h-100">
          <div class="card-body text-center">
            <h5 class="card-title">View Routes</h5>
            <a href="view_routes.php" class="btn btn-light mt-2">Go</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

  <!-- Footer -->
  <footer class="text-center mt-5 py-3 bg-dark text-light">
    <p>&copy; <?php echo date('Y'); ?> Transport Management System - Admin Panel</p>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
