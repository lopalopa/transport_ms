<?php
include('db.php');

if (isset($_GET['id'])) {
    $vehicle_id = intval($_GET['id']); // sanitize the ID
    $sql = "SELECT * FROM vehicles WHERE id = $vehicle_id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $vehicle = $result->fetch_assoc();
    } else {
        echo "Vehicle not found.";
        exit;
    }
} else {
    echo "Invalid vehicle ID.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Vehicle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        .vehicle-img {
            max-width: 300px;
            height: auto;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .details-container {
            max-width: 800px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
    </style>
</head>
<body>
<div class="container details-container">
    <h2 class="mb-4 text-center">Vehicle Details</h2>
    <div class="text-center mb-4">
        <?php if (!empty($vehicle['image'])): ?>
            <img src="uploads/<?= htmlspecialchars($vehicle['image']) ?>" alt="Vehicle Image" class="vehicle-img">
        <?php else: ?>
            <p>No image available.</p>
        <?php endif; ?>
    </div>

    <table class="table table-bordered">
        <tr><th>ID</th><td><?= htmlspecialchars($vehicle['id']) ?></td></tr>
        <tr><th>Vehicle Number</th><td><?= htmlspecialchars($vehicle['vehicle_no']) ?></td></tr>
        <tr><th>Name</th><td><?= htmlspecialchars($vehicle['vehicle_name']) ?></td></tr>
        <tr><th>Type</th><td><?= htmlspecialchars($vehicle['vehicle_type']) ?></td></tr>
        <tr><th>Status</th><td><?= htmlspecialchars($vehicle['status']) ?></td></tr>
    </table>

    <div class="text-end">
        <a href="view_vehicle_user.php" class="btn btn-secondary">Back to List</a>
    </div>
</div>
</body>
</html>
