<!-- footer.php -->
<footer class="bg-dark text-white text-center py-3 mt-5">
  <p>&copy; 2025 Transport Management System | Designed with ❤️</p>
  <p>
    <a href="privacy.php" class="text-white">Privacy Policy</a> |
    <a href="terms.php" class="text-white">Terms of Service</a>
  </p>
</footer>

<!-- Add Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
